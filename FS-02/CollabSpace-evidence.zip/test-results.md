# CollabSpace Test Results

**Run date:** 20 November 2026  
**Scope:** Existing automated tests in `src/apps/web/test` and `src/apps/server/test`  
**Result:** 3 passed, 0 failed

## Automated test cases

| Area | Test case | Result | Observed duration |
|---|---|---:|---:|
| Web / Yjs | Concurrent local document edits converge; document state can be restored | PASS | 10.04 ms |
| Server / API | Authentication, workspace and page CRUD, invite roles, and validation | PASS | 1,693.03 ms |
| Server / permissions | Workspace roles grant the expected edit and management abilities | PASS | 1.17 ms |

The web test command completed in **214.06 ms**. The server test command, including its TypeScript build, completed in **4,584.08 ms**. These are test-run timings from this machine, not production service latency measurements.

## Performance metrics

| Metric | Result |
|---|---|
| Automated test cases | 3 / 3 passed |
| Yjs convergence test | 10.04 ms |
| API CRUD/auth test | 1,693.03 ms |
| Permissions test | 1.17 ms |
| Concurrent editor sync latency (p50/p95/max) | Not measured |
| API request latency under concurrent load (p50/p95) | Not measured |
| Maximum stable concurrent editors | Not measured |

The repository includes `src/scripts/phase8-load-test.mjs` for concurrent editor and API latency measurements. A representative run needs the API, WebSocket server, PostgreSQL, Redis (optional for single-node WebSocket mode), and a seeded demo account. Docker could not connect to its engine in this environment, so the backing services were unavailable and no load-test numbers are claimed here.

## Screenshot evidence

Browser screenshots of the running local Next.js application are in [`screenshots/`](screenshots/):

- `01-login.png`
- `02-signup.png`

The dashboard and collaborative editor require a database-backed session and workspace; they could not be captured in this run.

## Reproduce the automated tests

From `FS-02/src` in PowerShell:

```powershell
npm.cmd test --workspace @collab/web
npm.cmd test --workspace @collab/server
```

For the load test, start the configured database, API and WebSocket services, seed a demo workspace/account, then run:

```powershell
npm.cmd run stress -- --editors 25 --pages 1
```

The load script creates and deletes a temporary workspace. Configure `DEMO_PASSWORD` or `LOAD_TEST_PASSWORD` in `.env` before running it.
